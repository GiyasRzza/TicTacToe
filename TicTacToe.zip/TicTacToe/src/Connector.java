public class Connector {
    public static String userOne;
    public static String userTwo;

}
